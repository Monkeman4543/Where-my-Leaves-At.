﻿namespace type
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.oekt.gorillatag.type";
        public const string Name = "GorillaText";
        public const string Version = "1.0.0";
    }
}
