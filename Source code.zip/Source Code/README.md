# GorillaText
A Conputer to type text in!

Saved text can be fond in type/Texts
